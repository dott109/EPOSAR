"""
     *************************************************************************
     *                                                                       *
     * THIS CODE HAS BEEN DEVELOPED WITHIN OPENAIRE-ADVANCED H2020 PROJECT   *
     *                                                                       *
     *************************************************************************




      file: EPOSAR_zenodo_upload.py
      function: to upload on the EPOSAR community on zenodo.org the products
                of the EPOSAR  service of the EPOS Thematic Core Service (TCS) satellite data
      author: Claudio De Luca, Michele Manunta
      last modification date: 2019-12-18

     ********************************************************************/
 
 
 
        the code exploits the zenodo API to upload a dataset in an already existing community
        by properly setting the required metadata.
        
        this code recieves as inputs four txt files including respectively:
         1. the API access token of the community
         2. the URL where the dataset will be uploaded
         3. the metadata list created by the developers
         4. the metadata list created by the user
        
        and the dataset file
         
         
        EXAMPLES:
            python EPOSAR_zenodo_upload.py <Access_Token_filename> URL.txt metaData.txt metaData_User.txt <file_name>
         

"""




import requests
import simplejson as json
import sys
import re
import json
from datetime import date



Access_Token_file = sys.argv[1]
URL_file = sys.argv[2]

f = open(Access_Token_file, "r")
Access_Token = (f.read()).strip()
f.close()

f = open(URL_file, "r")
URL = (f.read()).strip()
f.close()

metaData = sys.argv[3]
metaDataUser = sys.argv[4]
nomefile = sys.argv[5].strip()

print metaDataUser
print nomefile

#quit()
##############################################
print "Developers Metada: "

f = open(metaData, "r")
stringToMatch = 'communities'
matchedLine = ''
for line in f:
    if stringToMatch in line:
        matchedLine = line 
#        print matchedLine
        communities = matchedLine.split(":")[1].strip()
print "Community: "+communities
f.close()

f = open(metaData, "r")
stringToMatch = 'access_right'
matchedLine = ''
for line in f:
    if stringToMatch in line:
        matchedLine = line
#        print matchedLine
        access_right = matchedLine.split(":")[1].strip()
print "Access_Right: "+access_right
f.close()

f = open(metaData, "r")
stringToMatch = 'license'
matchedLine = ''
for line in f:
    if stringToMatch in line:
        matchedLine = line
#        print matchedLine
        license = matchedLine.split(":")[1].strip()
#print(license)
f.close()

f = open(metaData, "r")
stringToMatch = 'keywords'
matchedLine = ''
for line in f:
    if stringToMatch in line:
        matchedLine = line
#        print matchedLine
        keywords = matchedLine.split(":")[1].strip()
#print "Keywords: "+keywords
f.close()

f = open(metaData, "r")
stringToMatch = 'references'
matchedLine = ''
for line in f:
    if stringToMatch in line:
        matchedLine = line
#        print matchedLine
        references = matchedLine.split(":")[1].strip()
#print "References: "+references
f.close()

f = open(metaData, "r")
stringToMatch = 'language'
matchedLine = ''
for line in f:
    if stringToMatch in line:
        matchedLine = line
#        print matchedLine
        language = matchedLine.split(":")[1].strip()
print "Language: "+language
f.close()
#############################################
##leggiamo i metadata inseriti dall'utente###
print "User Metada: "



f = open(metaDataUser, "r")
stringToMatch = 'title'
matchedLine = ''
for line in f:
    if stringToMatch in line:
        matchedLine = line
#        print matchedLine
        title = matchedLine.split(":")[1].strip()
print "Title: "+title
f.close()


#f = open(metaDataUser, "r")
#stringToMatch = 'publication_type'
#matchedLine = ''
#for line in f:
#    if stringToMatch in line:
#        matchedLine = line
#        print matchedLine
#        publication_type = matchedLine.split(":")[1].strip()
#print(publication_type)
#f.close()


publication_date = str(date.today()).strip()
#f = open(metaDataUser, "r")
#stringToMatch = 'date'
#matchedLine = ''
#for line in f:
#    if stringToMatch in line:
#        matchedLine = line
#        print matchedLine
#        publication_date = matchedLine.split(":")[1]
#        publication_date = publication_date.strip()
#f.close()
print "Pubblication_Date: "+publication_date



f = open(metaDataUser, "r")
stringToMatch = 'upload_type'
matchedLine = ''
for line in f:
    if stringToMatch in line:
        matchedLine = line
#        print matchedLine
        upload_type = matchedLine.split(":")[1].strip()
print "Upload_Type: "+upload_type
f.close()




f = open(metaDataUser, "r")
stringToMatch = 'creators'
matchedLine = ''
for line in f:
    if stringToMatch in line:
        matchedLine = line
#        print matchedLine
        creators = matchedLine.split(":")[1].strip()
print "Creators: "+creators
f.close()


f = open(metaDataUser, "r")
stringToMatch = 'affiliation'
matchedLine = ''
for line in f:
    if stringToMatch in line:
        matchedLine = line
#        print matchedLine
        affiliation = matchedLine.split(":")[1].strip()
print "Affiliation: "+affiliation
f.close()


f = open(metaDataUser, "r")
stringToMatch = 'description'
matchedLine = ''
for line in f:
    if stringToMatch in line:
        matchedLine = line
#        print matchedLine
        description = matchedLine.split(":")[1].strip()
print "Description: "+description
f.close()


f = open(metaDataUser, "r")
stringToMatch = 'keywords'
matchedLine = ''
for line in f:
    if stringToMatch in line:
        matchedLine = line
#        print matchedLine
        keywordsU = matchedLine.split(":")[1].strip()
f.close()


f = open(metaDataUser, "r")
stringToMatch = 'references'
matchedLine = ''
for line in f:
    if stringToMatch in line:
        matchedLine = line
#        print matchedLine
        referencesU = matchedLine.split(":")[1].strip()
f.close()


print ""
print "Metadata merging"
#############################################
check=bool(keywordsU.strip())
#coma=","
if check == True:
	keywordsAll = keywords+','+keywordsU
else:
	keywordsAll = keywords
print "Keywords: "+keywordsAll



check=bool(referencesU.strip())
if check == True:
	referencesAll = references+" , "+referencesU
else:
	referencesAll = references
print "References: "+referencesAll

#############################################


#############################################
##PRE-RESERVATION DI UN DOI#################

headers = {"Content-Type": "application/json"}
r = requests.post(URL, params={'access_token': Access_Token }, json={}, headers=headers)
r.status_code
poba=r.json()
#print poba

doi= poba['metadata']['prereserve_doi']['doi']
recid= poba['metadata']['prereserve_doi']['recid']

doi = doi.strip()
recid = str(recid).strip()
print ""
print "pre-reserved doi: "+doi
print "recid: "+recid
############################################



#################################################
if upload_type == "image":
    #print "THE FILE TO UPLOAD IS AN IMAGE"
    data_cld = { 'metadata':
            { 'title': title,
            'publication_date': publication_date,
            'upload_type': upload_type,
            'image_type': "figure",
            'creators': [{'name': creators ,  'affiliation': affiliation}],
            'description': description,
            'communities':[{'identifier': communities}],
            'access_right': access_right,
            'license': license,
            'doi': doi,
            'keywords': [keywordsAll],
            'references': [referencesAll],
            'language': language,
            }
            }


if upload_type == "dataset":
    #print "THE FILE TO UPLOAD IS A DATASET"
    data_cld = { 'metadata':
            { 'title': title,
            'publication_date': publication_date,
            'upload_type': upload_type,
            'creators': [{'name': creators ,  'affiliation': affiliation}],
            'description': description,
            'communities':[{'identifier': communities}],
            'access_right': access_right,
            'license': license,
            'doi': doi,
            'keywords': [keywordsAll],
            'references': [referencesAll],
            'language': language,
            }
            }

if upload_type != "dataset" and upload_type != "image":
    print "UPLOAD_TYPE NOT ALLOWED"
    quit()

##################################################


deposition_id = r.json()['id']
print(deposition_id)
data = {'filename': nomefile}
files = {'file': open(nomefile, 'rb')}
#r = requests.post(URL+'/'+recid+'/files' % deposition_id, params={'access_token': Access_Token}, data=data, files=files)
r = requests.post(URL+'/'+recid+'/files', params={'access_token': Access_Token}, data=data, files=files)
print ""
print "STATUS OF NEW FILE UPLOADING:"
print(r.status_code)
#print r.json()



#r = requests.put(URL+'/'+recid % deposition_id,params={'access_token': Access_Token}, data=json.dumps(data_cld), headers=headers)
r = requests.put(URL+'/'+recid,params={'access_token': Access_Token}, data=json.dumps(data_cld), headers=headers)
print ""
print "STATUS OF METADATA PUTTING:"
print(r.status_code)
#print r.json()


#r = requests.post(URL+'/'+str(recid).strip()+'/actions/publish' % deposition_id,  params={'access_token': Access_Token} )
r = requests.post(URL+'/'+recid+'/actions/publish',  params={'access_token': Access_Token} )
print ""
print "STATUS OF PUBLISHING:"
print(r.status_code)





